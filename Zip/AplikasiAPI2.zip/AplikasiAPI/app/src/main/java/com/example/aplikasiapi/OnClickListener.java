package com.example.aplikasiapi;

public interface OnClickListener {
    void aksiKlik(int position);
}
